def sum(numbers):
    return sum(numbers)
